chrome.lastClickedUrl = "";

chrome.contextMenus.create({
    id: "RCP Url Converter",
    title: "To Local",
    contexts: ["all"],
    onclick: toLocal,
});

function toLocal(info, tab) {
    chrome.tabs.getSelected(
        null,
        tab => chrome.tabs.sendRequest(
            tab.id,
            {msg:"toLocal", lastUrl: chrome.lastClickedUrl},
        )
    )
}

chrome.runtime.onMessage.addListener(request => {
    if (request.msg === "gotHref") {
        console.log("last url: " + chrome.lastClickedUrl);
        chrome.lastClickedUrl = request.gotUrl;
        console.log("changed to url: " + chrome.lastClickedUrl);
    }
});
