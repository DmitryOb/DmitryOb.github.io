chrome.extension.onRequest.addListener(function (req) {
    if (req.msg === "toLocal") {
        let url = new URL(req.lastUrl);
        url.hostname = 'cp.op-local.net';
        navigator.clipboard.writeText(url.toString()).then(null, (err) => console.error('Could not copy text: ', err));
    }
});

window.addEventListener('contextmenu', e => {
    if (e.target && e.target.href) {
        let Url = e.target.href
        chrome.runtime.sendMessage({msg: "gotHref", gotUrl: Url});
    }
})
